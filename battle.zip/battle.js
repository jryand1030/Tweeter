var player1 = prompt('player 1 name');
var player2 = prompt('player 2 name');

alert('p1' + player1 + ', p2 ' + palyer2);